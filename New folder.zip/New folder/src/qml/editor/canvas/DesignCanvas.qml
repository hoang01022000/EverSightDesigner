import QtQuick
import QtQuick.Controls

Item {
    id: root

    property real zoom: 0.84
    readonly property real designWidth: 1280
    readonly property real designHeight: 720
    readonly property real viewportHorizontalPadding: 48
    readonly property real viewportVerticalPadding: 48
    readonly property real workspaceTopBarHeight: 42
    readonly property real workspaceStatusBarHeight: 24
    readonly property real editableHeight: designHeight - workspaceTopBarHeight - workspaceStatusBarHeight
    property string activeRatioText: ""
    property real activeRatioX: 0
    property real activeRatioY: 0

    function cellAt(localX, localY) {
        var cells = canvasViewModel.layoutCells
        var normalizedX = localX / root.designWidth
        var normalizedY = localY / root.editableHeight
        for (var i = cells.length - 1; i >= 0; --i) {
            var cell = cells[i]
            if (normalizedX >= cell.x && normalizedX <= cell.x + cell.width
                    && normalizedY >= cell.y && normalizedY <= cell.y + cell.height)
                return cell
        }
        return null
    }

    Rectangle {
        anchors.fill: parent
        color: "#303437"

        Canvas {
            anchors.fill: parent
            onPaint: {
                var ctx = getContext("2d")
                ctx.fillStyle = "#303437"
                ctx.fillRect(0, 0, width, height)
                ctx.strokeStyle = "#3a3e42"
                ctx.lineWidth = 1
                for (var x = 0; x < width; x += 10) {
                    ctx.beginPath()
                    ctx.moveTo(x, 0)
                    ctx.lineTo(x, height)
                    ctx.stroke()
                }
                for (var y = 0; y < height; y += 10) {
                    ctx.beginPath()
                    ctx.moveTo(0, y)
                    ctx.lineTo(width, y)
                    ctx.stroke()
                }
            }
        }
    }

    Flickable {
        id: canvasFlickable
        anchors.fill: parent
        contentWidth: Math.max(width, stageFrame.width * root.zoom + root.viewportHorizontalPadding)
        contentHeight: Math.max(height, stageFrame.height * root.zoom + root.viewportVerticalPadding)
        clip: true

        Item {
            id: zoomLayer
            x: Math.max(root.viewportHorizontalPadding / 2,
                        (canvasFlickable.width - stageFrame.width * root.zoom) / 2)
            y: Math.max(root.viewportVerticalPadding / 2,
                        (canvasFlickable.height - stageFrame.height * root.zoom) / 2)
            width: stageFrame.width * root.zoom
            height: stageFrame.height * root.zoom
            scale: root.zoom
            transformOrigin: Item.TopLeft

            Rectangle {
                id: stageFrame
                width: root.designWidth
                height: root.designHeight
                color: "#202225"
                border.color: "#ff7a00"
                border.width: 2

                WorkspaceTopBar {
                    id: workspaceTopBar
                    anchors.left: parent.left
                    anchors.right: parent.right
                    anchors.top: parent.top
                    height: root.workspaceTopBarHeight
                }

                Item {
                    id: editableArea
                    anchors.left: parent.left
                    anchors.right: parent.right
                    anchors.top: workspaceTopBar.bottom
                    anchors.bottom: workspaceStatusBar.top
                    clip: true

                    Canvas {
                        anchors.fill: parent
                        onPaint: {
                            var ctx = getContext("2d")
                            ctx.clearRect(0, 0, width, height)
                            ctx.fillStyle = "#232526"
                            ctx.fillRect(0, 0, width, height)
                            ctx.strokeStyle = "#363b40"
                            ctx.lineWidth = 1
                            for (var x = 0; x < width; x += 20) {
                                ctx.beginPath()
                                ctx.moveTo(x, 0)
                                ctx.lineTo(x, height)
                                ctx.stroke()
                            }
                            for (var y = 0; y < height; y += 20) {
                                ctx.beginPath()
                                ctx.moveTo(0, y)
                                ctx.lineTo(width, y)
                                ctx.stroke()
                            }
                        }
                    }

                    TapHandler {
                        acceptedButtons: Qt.LeftButton
                        onTapped: function(eventPoint) {
                            var targetCell = root.cellAt(eventPoint.position.x, eventPoint.position.y)
                            if (targetCell)
                                canvasViewModel.selectLayoutCell(targetCell.id,
                                                                 (eventPoint.event.modifiers & (Qt.ControlModifier | Qt.ShiftModifier)) !== 0)
                            else {
                                canvasViewModel.clearSelection()
                                canvasViewModel.clearLayoutCellSelection()
                            }
                        }
                    }

                    Menu {
                        id: cellContextMenu

                        MenuItem {
                            text: "Merge cells"
                            enabled: canvasViewModel.hasSelectedLayoutCell
                            onTriggered: canvasViewModel.mergeSelectedLayoutCells()
                        }
                    }

                    TapHandler {
                        acceptedButtons: Qt.RightButton
                        onTapped: function(eventPoint) {
                            cellContextMenu.popup(editableArea, eventPoint.position.x, eventPoint.position.y)
                        }
                    }

                    Rectangle {
                        anchors.centerIn: parent
                        width: 360
                        height: 118
                        radius: 3
                        color: "#424344"
                        border.color: "#585a5c"
                        visible: canvasViewModel.widgetCount === 0
                        z: 2

                        Column {
                            anchors.centerIn: parent
                            spacing: 8

                            Label {
                                anchors.horizontalCenter: parent.horizontalCenter
                                text: "Blank runtime screen"
                                color: "#e0e0e0"
                                font.pixelSize: 18
                                font.bold: true
                            }

                            Label {
                                anchors.horizontalCenter: parent.horizontalCenter
                                text: "Drag controls from the palette into a split region"
                                color: "#b8b8b8"
                                font.pixelSize: 13
                            }
                        }
                    }

                    Repeater {
                        model: canvasViewModel.layoutCells.length

                        delegate: Item {
                            id: regionContainer

                            required property int index
                            readonly property var cell: canvasViewModel.layoutCells[index]
                            property bool hovered: false

                            x: cell.x * editableArea.width
                            y: cell.y * editableArea.height
                            width: cell.width * editableArea.width
                            height: cell.height * editableArea.height
                            clip: true
                            z: cell.selected ? 20 : 10

                            Rectangle {
                                anchors.fill: parent
                                color: "transparent"
                                border.color: cell.selected || dropArea.containsDrag ? "#ff9a2c"
                                                   : (regionContainer.hovered ? "#7b858e" : "#4d555c")
                                border.width: cell.selected || dropArea.containsDrag ? 2
                                             : (regionContainer.hovered ? 1 : 1)
                            }

                            HoverHandler {
                                onHoveredChanged: regionContainer.hovered = hovered
                            }

                            TapHandler {
                                acceptedButtons: Qt.LeftButton

                                onTapped: function(eventPoint) {
                                    canvasViewModel.selectLayoutCell(regionContainer.cell.id,
                                                                     (eventPoint.event.modifiers & (Qt.ControlModifier | Qt.ShiftModifier)) !== 0)
                                }
                            }

                            Label {
                                anchors.left: parent.left
                                anchors.top: parent.top
                                anchors.margins: 6
                                z: 6
                                text: "Region " + cell.id
                                color: "#c8d0d8"
                                font.pixelSize: 11
                                visible: parent.width > 92 && parent.height > 38
                            }

                            DropArea {
                                id: dropArea
                                anchors.fill: parent
                                z: 4
                                keys: ["text/plain", "application/eversight-widget-type"]

                                onDropped: function(drop) {
                                    var type = ""
                                    if (drop.hasText)
                                        type = drop.text
                                    if (!type || type.length === 0)
                                        type = drop.getDataAsString("text/plain")
                                    if (!type || type.length === 0)
                                        return
                                    canvasViewModel.addWidgetToLayoutCellAt(type,
                                                                            cell.id,
                                                                            Math.max(0, drop.x - 80),
                                                                            Math.max(0, drop.y - 46))
                                }
                            }

                            Repeater {
                                model: canvasViewModel

                                delegate: WidgetNode {
                                    visible: model.widgetParentRegionId === regionContainer.cell.id
                                    widgetId: model.widgetId
                                    widgetType: model.widgetType
                                    widgetTitle: model.widgetTitle
                                    buttonColor: model.widgetButtonColor
                                    borderColorValue: model.widgetBorderColor
                                    iconColor: model.widgetIconColor
                                    componentSource: model.widgetComponentSource
                                    selected: model.widgetSelected

                                    x: model.widgetX
                                    y: model.widgetY
                                    width: model.widgetWidth
                                    height: model.widgetHeight
                                    z: model.widgetSelected ? 100 : 30

                                    boundsWidth: regionContainer.width
                                    boundsHeight: regionContainer.height

                                    onSelectedRequested: function(id, additive) {
                                        canvasViewModel.selectWidget(id, additive)
                                    }

                                    onGeometryCommitted: function(id, newX, newY, newWidth, newHeight) {
                                        canvasViewModel.updateWidgetGeometry(id, newX, newY, newWidth, newHeight)
                                    }
                                }
                            }
                        }
                    }

                    Repeater {
                        model: canvasViewModel.layoutResizeHandles.length

                        delegate: SplitterHandle {
                            required property int index
                            readonly property var handle: canvasViewModel.layoutResizeHandles[index]

                            orientation: handle.orientation
                            coordinateItem: editableArea
                            x: handle.orientation === "vertical"
                               ? handle.x * editableArea.width - width / 2
                               : handle.start * editableArea.width
                            y: handle.orientation === "vertical"
                               ? handle.start * editableArea.height
                               : handle.y * editableArea.height - height / 2
                            width: handle.orientation === "vertical"
                                   ? 12
                                   : Math.max(36, handle.length * editableArea.width)
                            height: handle.orientation === "vertical"
                                    ? Math.max(36, handle.length * editableArea.height)
                                    : 12
                            z: 5000

                            onDragged: function(deltaRatio) {
                                var normalizedDelta = handle.orientation === "vertical"
                                        ? deltaRatio / handle.parentWidth
                                        : deltaRatio / handle.parentHeight
                                var minFirst = handle.orientation === "vertical"
                                        ? 50 / (handle.parentWidth * editableArea.width)
                                        : 50 / (handle.parentHeight * editableArea.height)
                                var minSecond = minFirst
                                var nextRatio = Math.max(minFirst, Math.min(1 - minSecond, handle.ratio + normalizedDelta))
                                canvasViewModel.resizeDivider(handle.parentCellId, nextRatio, minFirst, minSecond)
                                root.activeRatioText = nextRatio.toFixed(2) + "*"
                                root.activeRatioX = handle.orientation === "vertical" ? handle.x * editableArea.width : handle.start * editableArea.width
                                root.activeRatioY = handle.orientation === "vertical" ? 0 : handle.y * editableArea.height
                            }

                            onMergeRequested: {
                                canvasViewModel.mergeLayoutSiblings(handle.firstCellId,
                                                                    handle.secondCellId)
                            }
                        }
                    }

                    Rectangle {
                        x: root.activeRatioX + 4
                        y: root.activeRatioY + 4
                        width: 46
                        height: 20
                        radius: 2
                        color: "#252a2f"
                        border.color: "#ff9a2c"
                        visible: root.activeRatioText.length > 0
                        z: 7000

                        Text {
                            anchors.centerIn: parent
                            text: root.activeRatioText
                            color: "#f4f6f8"
                            font.pixelSize: 11
                        }
                    }

                    Repeater {
                        model: canvasViewModel.layoutResizeHandles.length

                        delegate: Rectangle {
                            required property int index
                            readonly property var handle: canvasViewModel.layoutResizeHandles[index]

                            x: handle.orientation === "vertical" ? handle.x * editableArea.width - width / 2
                                                                  : handle.x * editableArea.width - width / 2
                            y: handle.orientation === "vertical" ? 2
                                                                  : handle.y * editableArea.height - height / 2
                            width: 44
                            height: 18
                            radius: 2
                            color: "#202428"
                            border.color: "#5f6870"
                            z: 6000

                            Text {
                                anchors.centerIn: parent
                                text: Number(handle.ratio).toFixed(2) + "*"
                                color: "#cbd3da"
                                font.pixelSize: 10
                            }

                            TapHandler {
                                acceptedButtons: Qt.LeftButton
                                onDoubleTapped: ratioEditor.openForHandle(handle.parentCellId,
                                                                          Number(handle.ratio).toFixed(2),
                                                                          parent.x,
                                                                          parent.y)
                            }
                        }
                    }

                    Rectangle {
                        id: ratioEditor
                        width: 54
                        height: 22
                        radius: 2
                        color: "#ffffff"
                        border.color: "#ff9a2c"
                        visible: false
                        z: 8000

                        property int parentCellId: -1

                        function openForHandle(parentId, value, editorX, editorY) {
                            parentCellId = parentId
                            x = editorX
                            y = editorY
                            ratioInput.text = value
                            visible = true
                            ratioInput.forceActiveFocus()
                            ratioInput.selectAll()
                        }

                        TextInput {
                            id: ratioInput
                            anchors.fill: parent
                            anchors.margins: 3
                            color: "#111820"
                            font.pixelSize: 11
                            horizontalAlignment: TextInput.AlignHCenter
                            verticalAlignment: TextInput.AlignVCenter

                            onAccepted: {
                                canvasViewModel.setExactRatio(ratioEditor.parentCellId, Number(text))
                                ratioEditor.visible = false
                            }

                            onEditingFinished: {
                                if (ratioEditor.visible) {
                                    canvasViewModel.setExactRatio(ratioEditor.parentCellId, Number(text))
                                    ratioEditor.visible = false
                                }
                            }
                        }
                    }

                    Rectangle {
                        id: topRuler
                        anchors.left: parent.left
                        anchors.right: parent.right
                        anchors.top: parent.top
                        height: 14
                        color: "#1f2327"
                        opacity: 0.92
                        z: 6500

                        DragHandler {
                            id: topRulerDrag
                            target: null
                            acceptedButtons: Qt.LeftButton
                            onActiveChanged: {
                                if (!active) {
                                    var point = topRuler.mapToItem(editableArea, centroid.position.x, centroid.position.y)
                                    if (point.y >= 0 && point.y <= editableArea.height)
                                        canvasViewModel.splitCellAt("vertical", point.x / editableArea.width, point.y / editableArea.height)
                                }
                            }
                        }
                    }

                    Rectangle {
                        id: leftRuler
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.bottom: parent.bottom
                        width: 14
                        color: "#1f2327"
                        opacity: 0.92
                        z: 6500

                        DragHandler {
                            id: leftRulerDrag
                            target: null
                            acceptedButtons: Qt.LeftButton
                            onActiveChanged: {
                                if (!active) {
                                    var point = leftRuler.mapToItem(editableArea, centroid.position.x, centroid.position.y)
                                    if (point.x >= 0 && point.x <= editableArea.width)
                                        canvasViewModel.splitCellAt("horizontal", point.x / editableArea.width, point.y / editableArea.height)
                                }
                            }
                        }
                    }
                }

                WorkspaceStatusBar {
                    id: workspaceStatusBar
                    anchors.left: parent.left
                    anchors.right: parent.right
                    anchors.bottom: parent.bottom
                    height: root.workspaceStatusBarHeight
                    regionText: canvasViewModel.hasSelectedLayoutCell
                                ? "Active region: " + canvasViewModel.selectedLayoutCellId
                                : "Ready"
                }
            }
        }
    }
}
